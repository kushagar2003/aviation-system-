# Avatition (version 2)

A chatbot that answers private-aviation questions such as "I am in Mumbai and must reach Delhi by the
morning of the 22nd" and "who can handle a medical emergency?". Data lives in Neon (PostgreSQL),
the code is Python and runs on your computer, and Gemini (later) does the language work.

## Folders

| Folder | What it holds |
|---|---|
| `data/` | The 10 companies and where each fact came from (source data) |
| `database/` | SQL: `01_schema.sql`, `02_data.sql`, `03_example_queries.sql` |
| `questions/` | `test_questions.txt`: 48 questions of 19 kinds, with the correct answer for each |
| `app/` | The Python code, built one file at a time |
| `tests/`, `run_tests.py` | Tests. `python run_tests.py` writes `test_results/test_report.txt` |
| `archive_v1/` | The first version, kept for reference only (see its `ARCHIVE_NOTE.md`) |

## Code built so far

| File | Job |
|---|---|
| `app/config.py` | Reads settings from `.env`; never prints secrets |
| `app/db.py` | Talks to the database (psycopg2 for Neon) |
| `app/load_data.py` | Creates the four tables and loads the data: `python -m app.load_data` |
| `app/check_connection.py` | Checks the laptop can reach Neon: `python -m app.check_connection` |

Still to build, in this order: `embed_companies`, `understand`, `retrieve`, `filter_rank`, `explain`, `pipeline`, `screen`.

## Running it on your computer

1. `pip install -r requirements.txt`
2. Copy `.env.example` to `.env` and paste your Neon connection string after `DATABASE_URL=`
3. `python -m app.check_connection`
4. `python -m app.load_data`

## Safety rules for GitHub

Never commit `.env`. It is already listed in `.gitignore`.
